import React from 'react'
import './FormDesign.css'
import { useFormik } from 'formik';

const initialValues = {
    name: '',
    email: '',
    channel: ''
  }

const onSubmit = values => {
  console.log('Form values',values);
}
  
const validate = values =>{
  let errors = {}
  if(!values.name)
  {
    errors.name = 'Required'
  }  

  if(!values.email)
  {
    errors.email = 'Required'
  } else if(!/^[A-Z0-9._%+-] + @[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email))
  {
    errors.email = 'Invalid form format.'
  }
  if(!values.channel)
  {
    errors.channel = 'Required'
  }

  return errors;
}
function CreateForm() {
      const formik = useFormik({
      initialValues,
      onSubmit,
      validate
    }) 
    
    

  return (
    <div className="maindiv">
        <form className='formDesign'>
            <div className="div1">
            <label htmlFor='name'>Name: <br></br></label>
            <input type='text' name = 'name' id = 'name' onChange = {formik.handleChange} value = {formik.values.name}/>
            </div>

            {formik.errors.name ? <div className = 'error'>{formik.errors.name}</div>:null}
            
            <div className="div2">
            <label htmlFor='email'>Email:<br></br> </label>
            <input type = 'email' name = 'email' id = 'email' onChange = {formik.handleChange} value = {formik.values.email}/>
            </div>

            {formik.errors.email ? <div className = 'error'>{formik.errors.email}</div>:null}

            <div className="div3">
            <label htmlFor='channel'>Channel: <br></br></label>
            <input type = 'text' id = 'channel' name = 'channel' onChange = {formik.handleChange} value = {formik.values.channel}/>
            </div>

            {formik.errors.channel ? <div className = 'error'>{formik.errors.channel}</div>:null}
            <button type='submit'>Submit</button>
        </form>
    </div>
  )
}

export default CreateForm;